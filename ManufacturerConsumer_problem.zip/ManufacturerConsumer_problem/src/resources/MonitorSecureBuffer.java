
package resources;
public class MonitorSecureBuffer extends InSecureBuffer implements IBuffer{
	public MonitorSecureBuffer(int n) {
		super(n);
		}
        @Override
		public synchronized void addElem() {
		while (index==n)
		try {
		wait();
		} catch (InterruptedException e) {
		Thread.currentThread().interrupt();
		break;
		}
                
		if (index!=n) {
		add();
		if (index==1) notifyAll();
		}
		}
        @Override
		public synchronized void readElem() {
		while (index==0)
		try {
		wait();
		} catch (InterruptedException e) {
		Thread.currentThread().interrupt();
		break;
		}
                
		if (index!=0) {
		read();
		if (index==(n-1)) notifyAll();
		}
		}
}
